//Associative arrays
const person = [];
person[0] = "John";
person[1] = "Doe";
person[2] = 46;
document.getElementById("demo").innerHTML = person[0] + " " + person.length;

//Nested arrays
let x = "";
const myObj = {
  name: "John",
  age: 30,
  cars: [
    { name: "Ford", models: ["Fiesta", "Focus", "Mustang"] },
    { name: "BMW", models: ["320", "X3", "X5"] },
    { name: "Fiat", models: ["500", "Panda"] },
  ],
};

for (let i in myObj.cars) {
  x += "<h2>" + myObj.cars[i].name + "</h2>";
  for (let j in myObj.cars[i].models) {
    x += myObj.cars[i].models[j] + "<br>";
  }
}


document.getElementById("demo1").innerHTML = x;

//JS join () method
const fruits = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo2").innerHTML = fruits.join(" * ");

//JS pop() method
const fruits_1 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo3").innerHTML = fruits_1;
fruits_1.pop();
document.getElementById("demo4").innerHTML = fruits_1;

//JS push() method
const fruits_2 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo5").innerHTML = fruits_2;
fruits_2.push("Kiwi");
document.getElementById("demo6").innerHTML = fruits_2;

//JS shift() method
const fruits_3 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo7").innerHTML = fruits_3;
fruits_3.shift();
document.getElementById("demo8").innerHTML = fruits_3;


//Bracket indexing
const fruits_4 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo9").innerHTML = fruits_4;
fruits_4[0] = "Kiwi";
document.getElementById("demo10").innerHTML = fruits_4;

//The length property
const fruits_5 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo11").innerHTML = fruits;
fruits_5[fruits_5.length] = "Kiwi";
document.getElementById("demo12").innerHTML = fruits_5;

//delete
const fruits_6 = ["Banana", "Orange", "Apple", "Mango"];

document.getElementById("demo13").innerHTML = "The first fruit is: " + fruits_6[0];

delete fruits_6[0];

document.getElementById("demo14").innerHTML = "The first fruit is: " + fruits_6[0];

//concat() method
const myGirls = ["Cecilie", "Lone"];
const myBoys = ["Emil", "Tobias", "Linus"];
const myChildren = myGirls.concat(myBoys);

document.getElementById("demo15").innerHTML = myChildren;

//copywithin() method
const fruits_7 = ["Banana", "Orange", "Apple", "Mango", "Kiwi", "Papaya"];
document.getElementById("demo16").innerHTML = fruits_7.copyWithin(2, 0, 2);

//flat()
const myArr = [
  [1, 2],
  [3, 4],
  [5, 6],
];

const newArr = myArr.flat();
document.getElementById("demo17").innerHTML = newArr;

//flat map
const myArr_1 = [1, 2, 3, 4, 5, 6];
const newArr_1 = myArr_1.flatMap((x) => [x, x * 10]);
document.getElementById("demo18").innerHTML = newArr_1;

//slice() method
const fruits_8 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo19").innerHTML = fruits_8;

fruits_8.splice(2, 0, "Lemon", "Kiwi");
document.getElementById("demo20").innerHTML = fruits_8;

const fruits_9 = ["Banana", "Orange", "Apple", "Mango"];
document.getElementById("demo21").innerHTML = fruits_9;
fruits_9.splice(0, 1);
document.getElementById("demo22").innerHTML = fruits_9;

//sorting an array
const months = ["Jan", "Feb", "Mar", "Apr"];
const sorted = months.toSorted();

document.getElementById("demo23").innerHTML = sorted;

const reversed = months.toReversed();

document.getElementById("demo24").innerHTML = reversed;

//numeric sort
const points = [40, 100, 1, 5, 25, 10];
document.getElementById("demo25").innerHTML = points;

points.sort(function (a, b) {
  return a - b;
});
document.getElementById("demo26").innerHTML = points;

//array iteration
const numbers = [45, 4, 9, 16, 25];

let txt = "";
numbers.forEach(myFunction);
document.getElementById("demo27").innerHTML = txt;

function myFunction(value, index, array) {
  txt += value + "<br>"; 
}

//map() method creates a new array by performing a function on each element of an array.
const numbers1 = [45, 4, 9, 16, 25];
const numbers2 = numbers1.map(myFunction);

document.getElementById("demo28").innerHTML = numbers2;

function myFunction(value, index, array) {
  return value * 2;
}